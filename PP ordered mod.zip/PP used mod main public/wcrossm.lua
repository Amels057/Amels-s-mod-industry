--Mounts relative paths for EDM, Textures and Liveries
mount_vfs_model_path	(current_mod_path.."/Shapes")
mount_vfs_texture_path (current_mod_path.."/Textures/")
mount_vfs_liveries_path (current_mod_path.."/Liveries")

-- Not sure about this yet :]
GT = {};
set_recursive_metatable(GT, GT_t.generic_stationary)
set_recursive_metatable(GT.chassis, GT_t.CH_t.STATIC);

--Life points of the object
GT.chassis.life = 50

--Shape EDM name
GT.visual.shape = "wcrossm"
GT.visual.shape_dstr = "wcrossm"

--Use this name for your folder inside Liveries
GT.Name = "wcrossm"

--Name that will appear inside ME
GT.DisplayName = _("*white cross medium")
GT.Rate = 0

-- Class/type of object; it will appear as "Extructure" inside "Static Objects" in ME
GT.DetectionRange  = 0;
GT.ThreatRange = 0;
GT.mapclasskey = "P0091000076";
GT.attribute = {wsType_Ground,wsType_Standing,wsType_NoWeapon,wsType_GenericFort,
                "Fortifications",
                "CustomAimPoint",
                };
GT.category = "Fortification";

add_surface_unit(GT)

