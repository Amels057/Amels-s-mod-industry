
declare_plugin("Phenom Production used mod",
{
	installed 	 = true,
	dirName	  	 = current_mod_path,
	version		 = "1.0",		 
	state		 = "installed",
	developerName= "Amels",
	info         =_("Phenom Production used mod created by Amels"),	
	
}
)
		
mount_vfs_model_path	(current_mod_path.."/Shapes")
mount_vfs_texture_path (current_mod_path.."/Textures/")


dofile(current_mod_path..'/bfcm16.lua')
dofile(current_mod_path..'/wcross.lua')
dofile(current_mod_path..'/wcrossb.lua')
dofile(current_mod_path..'/wcrossm.lua')
-----------------------------------------------------

plugin_done()